from .constants import CLayouts

layout = CLayouts()
